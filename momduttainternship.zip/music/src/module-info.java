/**
 * 
 */
/**
 * 
 */
module music {
	requires java.desktop;
}
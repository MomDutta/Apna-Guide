package cscorner;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class loginservlet
 * @param <PrintWritter>
 */
@WebServlet("/loginservlet")
public class loginservlet<PrintWritter> extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		

		try {
			PrintWriter out=response.getWriter();
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/momnew","root","Mom@123");
			String name=request.getParameter("n");
			String password =request.getParameter("p");
			int foo=Integer.parseInt(password);
			PreparedStatement p1=con.prepareStatement("select name from login where name=? and password=?");
			p1.setString(1,name);
			p1.setInt(2,foo);
			ResultSet rs=p1.executeQuery();
			if(rs.next()) {
				out.println("<h1>you are present<h1>");
				out.println("<a href='login.jsp'>next<a>");
			
			}
			else {
				out.println("<h1>you are absent<h1>");
				out.println("<a href='login.jsp'>try again<a>");
				
			}
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	

	}

}
